package com.example.whatstheweather;

import androidx.appcompat.app.AppCompatActivity;

import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

public class MainActivity extends AppCompatActivity {
    EditText getCity;
    Button getWeather;
    TextView weatherInfo;

    public void getInfo(View view) {
        try {
            String city = URLEncoder.encode(getCity.getText().toString(), "UTF-8");
            InputMethodManager mgr = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
            mgr.hideSoftInputFromWindow(getCity.getWindowToken(), 0);
            Downloader task = new Downloader();
            task.execute("https://api.openweathermap.org/data/2.5/weather?q=" + city + "&appid=0a6639bb5bf03cb22b18d2fa62693f3b");
            weatherInfo.setVisibility(View.VISIBLE);
        }
        catch (Exception e)
        {
            e.printStackTrace();
            Toast.makeText(getApplicationContext(),"Can't find weather", Toast.LENGTH_LONG);
        }
    }


    public class Downloader extends AsyncTask<String, Void, String>
    {

        @Override
        protected String doInBackground(String... strings) {
            URL url;
            String result = "";
            HttpURLConnection urlConnection = null;
            try {
                url = new URL(strings[0]);
                urlConnection = (HttpURLConnection) url.openConnection();
                InputStream in = urlConnection.getInputStream();
                InputStreamReader reader = new InputStreamReader(in);
                int data = reader.read();
                while(data != -1)
                {
                    char c = (char) data;
                    result += c;
                    data = reader.read();
                }
                return result;
            }
            catch (Exception e){
                //Toast.makeText(getApplicationContext(),"Can't find weather", Toast.LENGTH_LONG);
                e.printStackTrace();
            }
            return null;
        }



        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            try {
                JSONObject object = new JSONObject(s);
                String weather = object.getString("weather");
                JSONArray array = new JSONArray(weather);
                for (int i=0; i<array.length(); i++)
                {
                    JSONObject part = array.getJSONObject(i);
                    String main = part.getString("main");
                    String description = part.getString("description");
                    if(main != "" && description != "")
                    {
                        weatherInfo.setText("\nmain: " + main + "\n\ndescription: " + description);
                    }
                    else
                    {
                        Toast.makeText(getApplicationContext(),"Can't find weather", Toast.LENGTH_LONG);
                    }
                }
            }
            catch (Exception e)
            {
                Toast.makeText(getApplicationContext(),"Can't find weather", Toast.LENGTH_LONG);

            }
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getCity = findViewById(R.id.cityName);
        getWeather = findViewById(R.id.button);
        weatherInfo = findViewById(R.id.info);



    }
}